import React from "react"
import { Option } from "../../shared/types/adaptive"

interface Props {
  question: string
  options: Option[]
  selectedOption: number | null
  correctOption: number | null
  locked: boolean
  onSelect: (option: Option) => void
}

const QuestionCard: React.FC<Props> = ({
  question,
  options,
  selectedOption,
  correctOption,
  locked,
  onSelect
}) => {

  const getStyle = (id: number) => {

    if (!locked) {
      return selectedOption === id
        ? "border-blue-500 bg-blue-50"
        : "hover:bg-gray-50"
    }

    if (correctOption === id)
      return "border-green-500 bg-green-100"

    if (selectedOption === id)
      return "border-red-500 bg-red-100"

    return ""
  }

  return (

    <div className="bg-white rounded-xl shadow-lg p-6 transition">

      <h2 className="text-xl font-semibold text-gray-800 mb-6">
        {question}
      </h2>

      <div className="grid gap-3">

        {options.map((opt) => (

          <button
            key={opt.id}
            disabled={locked}
            onClick={() => onSelect(opt)}
            className={`border rounded-lg p-4 text-left transition-all duration-200
            ${getStyle(opt.id)}`}
          >
            {opt.option_text}
          </button>

        ))}

      </div>

    </div>

  )

}

export default QuestionCard